package com.example.pam.AntiqueList

data class AntiqueDTO(val name: String, val photo: Int, val distance: Int, val id: Int) {
}