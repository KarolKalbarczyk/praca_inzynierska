package com.example.pam

import android.app.Application
import com.example.myapplication.Database.AntiqueRepository
import com.example.myapplication.Database.AppDatabase


class SightseeingApp : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { AntiqueRepository(database.antiqueDao()) }
}